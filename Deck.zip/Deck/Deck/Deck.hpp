// Anthony Bisulco, Nathaniel Hartwig
// Fundamentals of Algorithms
// Project 2 MASTER MIND 2b
// Prototype of the Deck Class
// Deck class contains linked lists of cards in a deck 52 card
// These cards have value 1-13 where 1 is an Ace, 11 is Jack, 12 is Queen, 13 is King
// Deck class can create a card object given a void constructor
// additionally getSuitName are used to correspond a suit(0, 1, 2, 3) with a string
// the print out operator<< has been overloaded for this class
// a function to shuffle the cards along with a helper function to swap the cards has been created
// below is the prototype for these functions

#ifndef Deck_hpp
#define Deck_hpp
#include "Card.hpp"

#include "d_node.h"
#include <stdio.h>
#include "iostream"

// Begin Deck class declaration
class Deck{
    public:
    
        void shuffle(); // shuffles cards in the linked list to a random order
        friend std::ostream& operator <<(std::ostream& ostr, Deck& a);  // overloaded print operator to print linked list
        Deck(void);     // default constructor to create the deck
        ~Deck(void);    // deck class destructor
        void playFlip();// playFlip function declaration
    private:
        Card& getCard(int carNum);  // getCard function declaration
        void setCard(int carNum);   // setCard function declaration
        void carVal(Card &x, int &score);
        int bound_check(std::string prompt, int min , int max);     // bound checking function to check if input numbers within valid range
        Card deal(void);        //deals one of the 24 cards drawn from top of deck to the player.
        void replace(Card c);   // replacement function declaration, to place used card back at the bottom of deck
        node<Card> *front;      // pointer to initial linked list which contains deck, node object
        node<Card> *frontDeal;  // pointer to linked list which contains dealt cards
        void swap(int x, int y, std::string one, std::string two);  // swap function to switch two elements in the linked list
        std::string getSuitName(int a) const;   // gets the suit name for a given value 0 Club,1 Diamond,2 Heart,3 Spade
};  // end Deck class declaration

#endif /* Deck_hpp */
